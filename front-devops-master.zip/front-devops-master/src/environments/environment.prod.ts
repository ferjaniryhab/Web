export const environment = {
  production: true,
  url: "http://172.29.12.12:30408/SpringMVC"

};

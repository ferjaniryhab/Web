export class Product {
    idProduit : any;
    codeProduit : any;
    libelleProduit : any;
    prix : any;
    dateCreation:any;
    dateDerniereModification:any;
}

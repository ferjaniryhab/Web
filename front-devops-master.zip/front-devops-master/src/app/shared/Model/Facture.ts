export class Facture {
  idFacture: any
  montantRemise:any
  montantFacture:any
  dateCreationFacture:any
  dateDerniereModificationFacture:any
  archivee:any
}
